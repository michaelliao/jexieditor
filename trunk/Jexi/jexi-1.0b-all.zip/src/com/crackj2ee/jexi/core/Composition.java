/*
 * Created on 2004-8-8
 * Author: Xuefeng, Copyright (C) 2004, Xuefeng.
 */
package com.crackj2ee.jexi.core;

/**
 * The struct that can be compose. This is a marked interface. 
 * 
 * @author Xuefeng
 */
public interface Composition {

}
