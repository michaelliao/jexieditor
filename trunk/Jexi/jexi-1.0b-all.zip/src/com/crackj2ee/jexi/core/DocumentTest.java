/*
 * Created on 2004-7-29
 * Author: Xuefeng, Copyright (C) 2004, Xuefeng.
 */
package com.crackj2ee.jexi.core;

import junit.framework.TestCase;

/**
 * TODO...
 * 
 * @author Xuefeng
 */
public class DocumentTest extends TestCase {

    private Document doc1 = null;

    /*
     * @see TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
        doc1 = Document.createEmptyDocument(null);
    }

    public void testFirstParagraph() {
    }

    public void testLastParagraph() {
    }

    public void testGetParagraph() {
    }

    public void testGetPageCount() {
    }

    public void testGetPage() {
    }

}
