/*
 * Created on 2004-7-29
 * Author: Xuefeng, Copyright (C) 2004, Xuefeng.
 */
package com.crackj2ee.jexi.ui;

import junit.framework.TestCase;

/**
 * TODO...
 * 
 * @author Xuefeng
 */
public class ApplicationTest extends TestCase {

    public void testRun() {
        Application.instance().run();
    }

}
